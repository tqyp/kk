#1пузырь
def puz1_sort(a):
    i=len(a)-1 #индекс последнего элемента
    for z in range (0,i): 
        for x in range(0,i):
            if a[x]>a[x+1]: #сравнивает два элемента 
                a[x], a[x+1]= a[x+1], a[x] #ракировка
    return(a)
#2пуз
def puz2_sort(a):
    i=len(a)-1 #индекс последнего элемента
    for z in range (0,i): 
        for x in range(0,i-z): #сравнивает элементы не до конца с каждым шагом, т.к. последний элемент в списке уже отсартирован.
            if a[x]>a[x+1]: #сравнивает два элемента 
                a[x], a[x+1]= a[x+1], a[x] #ракировка
    return(a)

#недопуз
def puzogr_sort(a):
    n=len(a)
    while True:
        zam=False
        for k in range(1,n):
            if a[k-1]>a[k]:
                a[k-1],a[k]=a[k],a[k-1]
                zam=True
        n-=1
        if not(zam):
            return(a)
#Отобр
def obr_sort(a):
    n=len(a)
    for i in range(0,n-1):
        min=a[i]
        k=i
        for j in range(i+1,n):
            if min>a[j]:
                min=a[j]
                k=j
        else:
            a[k]=a[i]
            a[i]=min
    return(a)
#МАКСМИН
def maxmin_sort(a):
    i=0
    j=len(a)-1
    while i<j:
        MIN=a[i]
        t=i
        MAX=a[j]
        g=j
        for k in range(i, j+1):
            if MIN>a[k]:
                MIN=a[k]
                t=k
            if MAX<a[k]:
                MAX=a[k]
                g=k
        a[t]=a[i]
        a[i]=MIN
        if g==i:
            a[t]=a[j]
            a[j]=MAX
        else:
            a[g]=a[j]
            a[j]=MAX
        i+=1
        j-=1
    return(a)

#ВСТАЛИН
def vstalin_sort(a):
    for k in range(len(a)-1):
        r=k
        j=k+1
        while j<len(a):
            if a[j]<a[r]:
                r=j
            j+=1
        b=a[k]
        a[k]=a[r]
        a[r]=b
    return(a)
#fastest
def rsort(a):
    if a == []:
        return a
    l = [i for i in a if i < a[0]]
    m = [i for i in a if i == a[0]]
    r = [i for i in a if i > a[0]]
    return rsort(l) + m + rsort(r)
