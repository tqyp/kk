#!Разработать две программы. Первая принимает от пользователя прямоугольную матрицу, сортирует по убыванию заданный столбец и выводит 
#на экран. Вторая программа выпускает первую в качестве вновь созданного процесса.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label, Text
from tkinter import messagebox as mb

def rsort(a): # быстрая сортировка
    if a == []:
        return a
    l = [i for i in a if i > a[0]]
    m = [i for i in a if i == a[0]]
    r = [i for i in a if i < a[0]]
    return rsort(l) + m + rsort(r)

def matrix():
    text = tx1.get(1.0, 'end')
    try: # проверка формата файла и содержимого
        length = len(text[:text.index('\n')].split(' ')) # определение длины
        lines = text.replace('\n', ' ')[:-1] # слияние чисел в 1 список
        matrix = list(map(int, lines.split(' '))) # разбиение данных на список чисел
        if len(matrix) % length != 0: # проверка на прямоугольность
            mb.showerror('Ошибка!', 'Не является матрицей!')
            return
    except:
        mb.showerror('Ошибка!', 'Некорректный ввод матрицы!')
        return
    try:
        tx1.delete(1.0, 'end')
        inp = int(ent.get())-1
        column = [] # переменные записи
        for i in range(0, len(matrix), length): # цикл по строкам
            row = list(map(str,matrix[i:i+length])) # определение строки
            tx1.insert('end', ' '.join(row)+'\n')
            column += [matrix[i+inp]] # запись чисел столбца
        colsorted = ' '.join(map(str,rsort(column))) # сортировка
        tx1.insert('end', '\nОтсортированный столбец: '+colsorted)
    except:
        mb.showerror('Ошибка!', 'Некорректный ввод номера столбца!')     

r = Tk()
r.title('Билет 10')
r.geometry('330x400')
r.resizable(0, 0)
lb1 = Label(r, text = 'Номер сортируемого столбца:', font = 'Consolas 12')
lb1.place(x = 10, y = 10)
ent = Entry(r, font = 'Consolas 12', width = 5)
ent.place(x = 265, y = 10)
lb2 = Label(r, text = 'Введите матрицу:', font = 'Consolas 12')
lb2.place(x = 10, y = 45)
tx1 = Text(r, width = 37, height = 16)
tx1.place(x = 15, y = 80)
btn = Button(r, text = 'Отсортировать', font = 'Consolas 12')
btn.bind('<Button-1>', lambda x: matrix())
btn.place(x = 15, y = 355)
r.mainloop()
