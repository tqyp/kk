from sqlite3 import connect

connection = connect('personnelRecord.db')
cursor = connection.cursor()
cursor.execute('''create table employees(empNum int primary key, fullName text,
               birthDate date, specCode int, divCode int, arrivalDate date,
               startDate date, salary int, education text, posCode int)''')
cursor.execute('''insert into employees values(0, "Васильев Иван Иванович",
               "1973-11-13", 143, 8, "2021-11-23", "2021-11-25",
               37000, "Высшее", 12)''')
connection.commit()
connection.close()
