from random import randint

from PyQt5 import QtWidgets, uic
from PyQt5.QtCore import QDate
from PyQt5.QtWidgets import QMessageBox, QTableWidgetItem

Form, _ = uic.loadUiType("untitled.ui")


class MyWin(QtWidgets.QMainWindow, Form):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self, parent)
        self.setupUi(self)
        self.zap()  # Автоматический запуск функции при открытие программы
        self.pushButton_3.clicked.connect(self.add)  # Обработка кнопки добавления
        self.pushButton_4.clicked.connect(self.delet)  # Обработка кнопки удаления
        self.pushButton.clicked.connect(self.sort)  # Обработка кнопки сортировки
        self.pushButton_2.clicked.connect(self.view)  # Обработка кнопки отображения матрицы

    def zap(self):  # Функция формирования случайной матрицы и поиск диагоналей
        global matrix, glav, poboh
        rows = self.tableWidget.rowCount()
        cols = self.tableWidget.columnCount()
        matrix = [[randint(1, 101) for j in range(cols)] for i in range(rows)]  # генератор матрицы
        row = 0
        col = 0
        glav = []
        poboh = []
        for i in matrix:  # Вывод матрицы на экран
            for j in i:
                self.tableWidget.setItem(row, col, QTableWidgetItem(str(j)))
                col += 1
            col = 0
            row += 1
        col = cols
        for i in range(rows):  # Поиск диагоналей
            glav.append(matrix[i][i])
            poboh.append(matrix[i][col - 1])
            col -= 1
        poboh.reverse()  # Переворачиваем побочную диагональ
        self.lineEdit_2.setText(str(glav))
        self.lineEdit.setText(str(poboh))

    def add(self):  # Функция добавления
        self.tableWidget.setRowCount(self.tableWidget.rowCount() + 1)
        self.tableWidget.setColumnCount(self.tableWidget.columnCount() + 1)
        self.zap()

    def delet(self):  # Функция удаления
        if self.tableWidget.rowCount() > 3:
            self.tableWidget.setRowCount(self.tableWidget.rowCount() - 1)
            self.tableWidget.setColumnCount(self.tableWidget.columnCount() - 1)
            self.zap()
        else:
            QMessageBox.about(self, "Ошибка",
                              "Минимальная квдратная матрица должна состоять из девяти элементов")

    def sort(self):  # Функция сортировки
        global matrix, glav, poboh
        rows = self.tableWidget.rowCount()
        cols = self.tableWidget.columnCount()
        matrix = []
        for row in range(rows):
            tmp = []
            for col in range(cols):
                try:
                    tmp.append(int(self.tableWidget.item(row, col).text()))
                except:
                    tmp.append('No data')
            matrix.append(tmp)
        col = cols
        glav = []
        poboh = []
        for i in range(rows):
            glav.append(matrix[i][i])
            poboh.append(matrix[i][col - 1])
            col -= 1
        for i in range(len(glav) - 1):  # сортировка методом пузырька по возрастанию
            for j in range(len(glav) - i - 1):
                if glav[j] > glav[j + 1]:
                    glav[j], glav[j + 1] = glav[j + 1], glav[j]
        for i in range(len(poboh) - 1):  # сортировка методом пузырька по убыванию
            for j in range(len(poboh) - i - 1):
                if poboh[j] < poboh[j + 1]:
                    poboh[j], poboh[j + 1] = poboh[j + 1], poboh[j]
        self.lineEdit_2.setText(str(glav))
        self.lineEdit.setText(str(poboh))

    def view(self):  # отображение матрицы
        row = 0
        col = 0
        for i in range(len(glav)):
            matrix[row][col] = glav[col]
            row += 1
            col += 1
        row = self.tableWidget.rowCount()
        col = 0
        for i in range(len(glav)):
            matrix[row - 1][col] = poboh[col]
            row -= 1
            col += 1
        row = 0
        col = 0
        for i in matrix:
            for j in i:
                self.tableWidget.setItem(row, col, QTableWidgetItem(str(j)))
                col += 1
            col = 0
            row += 1


if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    myapp = MyWin()
    myapp.show()
    sys.exit(app.exec_())
