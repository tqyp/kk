#!Дан текстовый файл и целое число Р. Создайте два выходных файла: в один перепишите из каждой строки первые Р слов, в другой - оставшиеся. 
#Если в строке меньше, чем Р слов, то во втором файле соответствующая строка должна быть пустой.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label, Text
from tkinter import messagebox as mb

def save():
    try: # проверка формата файла и разбиение содержимого в список
        file = open(ent.get(), 'r', encoding = 'utf-8')
        text = file.read().split('\n')
        for i in range(len(text)):
            text[i] = text[i].split(' ')
        inpnum = int(ent2.get())
    except:
        mb.showerror('Ошибка!', 'Неверный формат файла!')
        return
    newtext = '' # переменные для результата
    newtext2 = ''
    for line in text: # цикл разбиения строк
        if len(line) > inpnum: # если слов в строке больше, чем введенное число
            newtext += ' '.join(line[:inpnum]) + '\n'
            newtext2 += ' '.join(line[inpnum:]) + '\n'
        else: # если меньше
            newtext += ' '.join(line) + '\n'
            newtext2 += '\n'
    file = open('result.txt', 'w', encoding = 'utf-8') # запись результатов
    file.write(newtext[:-1])
    file.close()
    file2 = open('result2.txt', 'w', encoding = 'utf-8')
    file2.write(newtext2[:-1])
    file2.close()
    mb.showinfo('Успешно!','Файл с результатом создан!')

def chfile(): # открытие файла через ask
    ent.delete(0, 'end')
    ent.insert('end', ask())
    ent.xview_moveto(1)

r = Tk()
r.title('Билет 5')
r.geometry('450x90')
r.resizable(0, 0)
lbl = Label(text = 'Выберите файл:', font = 'Consolas 12')
lbl.place(x = 10, y = 10)
ent = Entry(font = 'Consolas 14', width = 20)
ent.place(x = 150, y = 10)
lbl = Label(text = 'Введите число разделения:', font = 'Consolas 12')
lbl.place(x = 10, y = 50)
ent2 = Entry(font = 'Consolas 14', width = 4)
ent2.place(x = 265, y = 50)
btn = Button(text = '...', font = 'Consolas 10')
btn.bind('<Button-1>', lambda x: chfile())
btn.place(x = 365, y = 10)
btn2 = Button(text = 'Сохранить', font = 'Consolas 10')
btn2.bind('<Button-1>', lambda x: save())
btn2.place(x = 325, y = 50)
r.mainloop()
