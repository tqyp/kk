from PyQt5.QtWidgets import QApplication, QMainWindow, QGridLayout, QWidget, QTableWidget, QTableWidgetItem
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtWidgets import QMenu
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QInputDialog, QLineEdit, QFileDialog
from PyQt5.QtGui import QIcon
from PyQt5.QtGui import QPalette
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QPushButton
import os.path
from PyQt5 import QtWidgets, QtCore
import tkinter.filedialog as fd
passw = '4810'

import sqlite3
 
con = sqlite3.connect("Дом.db") # или :memory: чтобы сохранить в RAM

cur = con.cursor()
cur.execute("SELECT * FROM Квартиры")
version = cur.fetchall()
result = version
sc = len(result)


    

from PyQt5.QtWidgets import QApplication, QMainWindow, QGridLayout, QWidget, QTableWidget, QTableWidgetItem
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QMenu
from PyQt5.QtWidgets import QMessageBox
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import QWidget, QMessageBox, QApplication
from tkinter import *




now_table = "Квартиры"
name_t = ['Номер квартиры','Колиичество жильцов','Фамилия хозяина','Выход в интернет']

class MainWindow(QMainWindow):
    
    def setupUi(self, Form):
        global lable9
        Form.setObjectName("Form")
        
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)
        

    def __init__(self):
        global p, table, grid_layout, label9
        # Обязательно нужно вызвать метод супер класса
        QMainWindow.__init__(self)
     
        self.setFixedSize(QSize(690, 621))             # Устанавливаем размеры
        self.setWindowTitle("Работа с QTableWidget")    # Устанавливаем заголовок окна
        self.centralwidget = QtWidgets.QWidget(self)
        self.centralwidget.setObjectName("centralwidget")
        self.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(self)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 929, 21))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        self.menu_5 = QtWidgets.QMenu(self.menubar)
        self.menu_5.setObjectName("menu_5")
        self.menu_2 = QtWidgets.QMenu(self.menubar)
        self.menu_2.setObjectName("menu_2")
        self.menu_3 = QtWidgets.QMenu(self.menubar)
        self.menu_3.setObjectName("menu_3")
        self.menu_6 = QtWidgets.QMenu(self.menubar)
        self.menu_6.setObjectName("menu_6")
        self.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(self)
        self.statusbar.setObjectName("statusbar")
        self.setStatusBar(self.statusbar)
        self.action = QtWidgets.QAction(self)
        self.action.setObjectName("action")
        self.actionn = QtWidgets.QAction(self)
        self.actionn.setObjectName("actionn")
        self.action_1 = QtWidgets.QAction(self)
        self.action_1.setObjectName("action_1")
        self.action_11 = QtWidgets.QAction(self)
        self.action_11.setObjectName("action_11")

        self.menu_2.addAction(self.action_1)
        self.menu_2.addAction(self.action_11)
        self.menu_3.addAction(self.action)
        self.menu_3.addAction(self.actionn)
    
        self.menubar.addAction(self.menu_2.menuAction())
        self.menubar.addAction(self.menu_3.menuAction())  

        
        #grid_layout = QGridLayout()             # Создаём QGridLayout
        gridLayoutWidget = QtWidgets.QWidget(self)
        gridLayoutWidget.setGeometry(QtCore.QRect(10, 30, 1311, 401))
        gridLayoutWidget.setObjectName("gridLayoutWidget")
        grid_layout = QtWidgets.QGridLayout(gridLayoutWidget)
        grid_layout.setContentsMargins(0, 0, 0, 0)
        grid_layout.setObjectName("grid_layout")
        #central_widget.setLayout(grid_layout)   # Устанавливаем данное размещение в центральный виджет
        self.setLayout(grid_layout)

        
        table = QTableWidget(self)  # Создаём таблицу
        table.setColumnCount(len(name_t))     # Устанавливаем три колонки
        table.setRowCount(len(result))        # и одну строку в таблице
     
        # Устанавливаем заголовки таблицы
        
        table.setHorizontalHeaderLabels(name_t)
        label9 = QtWidgets.QLabel(self)
        label9.setGeometry(QtCore.QRect(20, 450, 90, 16))
        label9.setObjectName("label9")
        label9.setText(("количество: "+str(len(result))))
        # Устанавливаем выравнивание на заголовки
        table.horizontalHeaderItem(0).setTextAlignment(Qt.AlignLeft)
        table.horizontalHeaderItem(1).setTextAlignment(Qt.AlignLeft)
        #table.horizontalHeaderItem(2).setTextAlignment(Qt.AlignLeft)
        p=0
        for i in result:
            h=0
            for j in i:
                table.setItem(p, h, QTableWidgetItem(str(j)))
                h+=1
            p+=1
                    
     
        # делаем ресайз колонок по содержимому
        table.resizeColumnsToContents()
     
        grid_layout.addWidget(table, 0, 0)   # Добавляем таблицу в сетку

     

        
    
    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.menu_2.setTitle(_translate("Form", "Запрос"))
        self.menu_3.setTitle(_translate("Form", "Действия с таблицей"))
        self.action_1.setText(_translate("Form", "Поиск"))
        self.action_11.setText(_translate("Form", "Вывод"))
        self.action.setText(_translate("Form", "Добавить"))
        self.actionn.setText(_translate("Form", "Уничтожить"))

        self.action_1.triggered.connect(self.seorch)
        self.action_11.triggered.connect(self.out)
        self.action.triggered.connect(self.dobav)
        self.actionn.triggered.connect(self.dell)
        



    def seorch(self, Form):

        def poisk():
            atr = comboExampl.get()
            zapa = txt2.get()
            try:
                cur.execute(f"SELECT * FROM {now_table} WHERE {atr} = {zapa}")
                result = cur.fetchall()
                if result == []:
                    int(result)
            except:
                cur.execute(f"SELECT * FROM {now_table} WHERE {atr} = '{zapa}'")
                result = cur.fetchall()
                if result == []:
                    QMessageBox.about(self,"Ошибка","Данная запись не существует либо введено ошибочное значение!!")
                    return

                    
            table = QTableWidget(self)  # Создаём таблицу
            table.setColumnCount(len(name_t))     # Устанавливаем три колонки
            table.setRowCount(len(result))        # и одну строку в таблице
         
            # Устанавливаем заголовки таблицы
            table.setHorizontalHeaderLabels(name_t)
            label9.setText(("количество: "+str(len(result))))
            # Устанавливаем выравнивание на заголовки
            table.horizontalHeaderItem(0).setTextAlignment(Qt.AlignLeft)
            p=0
            for i in result:
                h=0
                for j in i:
                    table.setItem(p, h, QTableWidgetItem(str(j)))
                    h+=1
                p+=1
            table.resizeColumnsToContents()
         
            grid_layout.addWidget(table, 0, 0)   # Добавляем таблицу в сетку
            
        window = Tk()
        window.title(f"Поиск записей по пределённому признаку в  таблице {now_table}")
        
        window.geometry('570x130')
        window.resizable(width=False, height=False)
        txt2 = Entry(window) 
        txt2.grid(column=1, row=2,pady=(5,0))

        
        from tkinter import ttk

        cur.execute(f"pragma table_info({now_table})")
        vers = cur.fetchall()
        lbl = Label(window, text="   Атрибут 1:   ")  
        lbl.grid(column=0, row=1, pady=(7,3))
        lbl = Label(window, text="   Значение:   ")  
        lbl.grid(column=0, row=2, pady=(7,3))
        taiwan = []
        for i in vers:
            taiwan.append(i[1])

            
        comboExampl = ttk.Combobox(window, values=taiwan, width = 22)
        comboExampl.grid(column=1, row=1)
                
        btn = Button(window, text="Обнаружить запись", command = lambda: poisk())  
        btn.place(x=350, y=20)
        
        window.mainloop()

    def out(self, Form):

        cur.execute("SELECT * FROM Квартиры")
        version = cur.fetchall()
        result = version
        table = QTableWidget(self)  # Создаём таблицу
        table.setColumnCount(len(name_t))     # Устанавливаем три колонки
        table.setRowCount(len(result))        # и одну строку в таблице
         
        # Устанавливаем заголовки таблицы
        table.setHorizontalHeaderLabels(name_t)
        label9.setText(("количество: "+str(len(result))))
        # Устанавливаем выравнивание на заголовки
        table.horizontalHeaderItem(0).setTextAlignment(Qt.AlignLeft)
        #table.horizontalHeaderItem(1).setTextAlignment(Qt.AlignLeft)
        #table.horizontalHeaderItem(2).setTextAlignment(Qt.AlignLeft)
        p=0
        for i in result:
            h=0
            for j in i:
                table.setItem(p, h, QTableWidgetItem(str(j)))
                h+=1
            p+=1
        table.resizeColumnsToContents()
         
        grid_layout.addWidget(table, 0, 0)   # Добавляем таблицу в сетку

    def dell(self, Form):
        
        def poisk():
            atr = comboExampl.get()
            zapa = txt2.get()
            cur.execute("SELECT * FROM Квартиры")
            version = cur.fetchall()
            sc = len(version)
            try:
                cur.execute(f"DELETE from {now_table} where {atr} = '{zapa}'")
                con.commit()
            except:
                try:
                    cur.execute(f"DELETE from {now_table} where {atr} = {zapa}")
                    con.commit()
                except:
                    QMessageBox.about(self,"Ошибка","Записей по данному условию не  существует!!")
                
            cur.execute("SELECT * FROM Квартиры")
            version = cur.fetchall()
            result = version

            if sc == len(result):
                print(90)
                QMessageBox.about(self,"Ошибка","Записей по данному условию не  существует!!")
            
            
            table = QTableWidget(self)  # Создаём таблицу
            table.setColumnCount(len(name_t))     # Устанавливаем три колонки
            table.setRowCount(len(result))        # и одну строку в таблице
         
            # Устанавливаем заголовки таблицы
            table.setHorizontalHeaderLabels(name_t)
            label9.setText(("количество: "+str(len(result))))
            # Устанавливаем выравнивание на заголовки
            table.horizontalHeaderItem(0).setTextAlignment(Qt.AlignLeft)
            #table.horizontalHeaderItem(1).setTextAlignment(Qt.AlignLeft)
            #table.horizontalHeaderItem(2).setTextAlignment(Qt.AlignLeft)
            p=0
            for i in result:
                h=0
                for j in i:
                    table.setItem(p, h, QTableWidgetItem(str(j)))
                    h+=1
                p+=1
            table.resizeColumnsToContents()
         
            grid_layout.addWidget(table, 0, 0)   # Добавляем таблицу в сетку
            
        window = Tk()
        window.title(f"Удаление записей по пределённому признаку в  таблице {now_table}")
        
        window.geometry('570x130')
        window.resizable(width=False, height=False)
        txt2 = Entry(window) 
        txt2.grid(column=1, row=2,pady=(5,0))

        
        from tkinter import ttk

        cur.execute(f"pragma table_info({now_table})")
        vers = cur.fetchall()
        lbl = Label(window, text="   Атрибут 1:   ")  
        lbl.grid(column=0, row=1, pady=(7,3))
        lbl = Label(window, text="   Значение:   ")  
        lbl.grid(column=0, row=2, pady=(7,3))
        taiwan = []
        for i in vers:
            taiwan.append(i[1])

            
        comboExampl = ttk.Combobox(window, values=taiwan, width = 22)
        comboExampl.grid(column=1, row=1)
                
        btn = Button(window, text="Удалить запись", command = poisk)  
        btn.place(x=350, y=20)
        
        window.mainloop()

    def dobav(self, Form):
            global txt0
            global txt1
            global txt2
            global txt4
            global txt6
            global txt7 
            def addTable():
                global txt0
                global txt1
                global txt2
                global txt4
                global txt6
                global txt7 
                global result
                zapa0 = txt0.get()
                zapa1 = txt1.get()
                zapa2 = txt2.get()
                zapa4 = txt4.get()
                try:
                    int(zapa0)
                except:
                    QMessageBox.about(self,"Ошибка","НЕВЕРНО ВВЕДЕНО ЗНАЧЕНИЕ Номер Квартиры, только целые числа")
                    return
                try:
                    int(zapa1)
                except:
                    QMessageBox.about(self,"Ошибка","НЕВЕРНО ВВЕДЕНО ЗНАЧЕНИЕ Количество жильцов, только целые числа")
                    return
                try:
                    za2 = zapa2.lower()
                    if za2.islower() == False:
                        int(result)
                except:
                    QMessageBox.about(self,"Ошибка","НЕВЕРНО ВВЕДЕНО ЗНАЧЕНИЕ Фамилия хозяина, только строчные")
                    return
                try:
                    za4 = zapa4.lower()
                    if za4.islower() == False:
                        int(result)
                    if zapa4 == 'Да' or zapa4 == 'Нет':
                        pass
                    else:
                        QMessageBox.about(self,"Ошибка","НЕВЕРНО ВВЕДЕНО ЗНАЧЕНИЕ Интернет, только Да или Нет")
                        return
                except:
                    QMessageBox.about(self,"Ошибка","НЕВЕРНО ВВЕДЕНО ЗНАЧЕНИЕ Интернет, только строчные")
                    return
                
                if 1 == 1:
                    try:                    
                        cur.execute(f"INSERT INTO {now_table} VALUES({zapa0},{zapa1},'{zapa2}','{zapa4}')")
                        con.commit()
                    except:
                        QMessageBox.about(self,"Ошибка","Данная запись существует!!")
                        return
                    
                
                cur.execute(f'Select * from {now_table}')
                result=cur.fetchall()
                
                table = QTableWidget(self)  # Создаём таблицу
                table.setColumnCount(len(name_t))     # Устанавливаем три колонки
                table.setRowCount(len(result))        # и одну строку в таблице
                # Устанавливаем заголовки таблицы
                table.setHorizontalHeaderLabels(name_t)
                label9.setText(("количество: "+str(len(result))))
                # Устанавливаем выравнивание на заголовки
                table.horizontalHeaderItem(0).setTextAlignment(Qt.AlignLeft)
                table.horizontalHeaderItem(1).setTextAlignment(Qt.AlignLeft)
                #table.horizontalHeaderItem(2).setTextAlignment(Qt.AlignLeft)
                p=0
                for i in result:
                    h=0
                    for j in i:
                        table.setItem(p, h, QTableWidgetItem(str(j)))
                        h+=1
                    p+=1
                table.resizeColumnsToContents()
             
                grid_layout.addWidget(table, 0, 0)   # Добавляем таблицу в сетку

            

            def clean():
                print(7895489756789568796578956875689568596)
                try:
                    txt0.delete(0, 'end')
                    txt0.insert(0, '')
                    txt1.delete(0, 'end')
                    txt1.insert(0, '')
                    txt2.delete(0, 'end')
                    txt2.insert(0, '')
                    txt4.delete(0, 'end')
                    txt4.insert(0, '')
                    txt6.delete(0, 'end')
                    txt6.insert(0, '')
                    txt7.delete(0, 'end')
                    txt7.insert(0, '')
                except:
                    pass
                    

                    
            window = Tk()
            window.title(f"Добавление записей в таблицу {now_table}")
            window.resizable(width=False, height=False)
            window.configure(bg = '#98FB98')
            
            yg = 0
            xg = 0
            mtxt = []
            t = "txt"
            num = 0
            for i in name_t:
                lbl = Label(window, text=" "+i+" ", bg = '#98FB98')  
                lbl.grid(column=xg, row=yg, pady=(5,0))
                mtxt.append(t+str(num))
                yg+=1
                num+=1
            if now_table == now_table:
                window.geometry('570x370')
                txt0 = Entry(window) 
                txt0.grid(column=1, row=0,pady=(5,0))
                txt1 = Entry(window) 
                txt1.grid(column=1, row=1,pady=(5,0))
                txt2 = Entry(window) 
                txt2.grid(column=1, row=2,pady=(5,0))     
                txt4 = Entry(window) 
                txt4.grid(column=1, row=3,pady=(5,0))              

            
            btn = Button(window, text="Добавить запись", command = addTable)  
            btn.place(x=350, y=20)
            btn1 = Button(window, text="  Очистить поля ", command = clean)  
            btn1.place(x=350, y=60)
            
            window.mainloop()

        




if __name__ == "__main__":
    import sys
 
    app = QApplication(sys.argv)
    mw = MainWindow()
    mw.setupUi(mw)
    mw.show()
    sys.exit(app.exec())
