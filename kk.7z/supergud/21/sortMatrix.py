from tkinter import *
from tkinter import messagebox
from displayMatrix import window

matrix = [[1, 2, 3, 4, 5],
          [6, 3, 3, 4, 5],
          [1, 5, 3, 4, 5],
          [1, 4, 3, 4, 5],
          [1, 1, 3, 4, 5],]

column = 1

def sort(matrix, column):
    swapped = True
    while swapped:
        swapped = False
        for i in range(len(matrix) - 1):
            if matrix[i][column] > matrix[i + 1][column]:
                matrix[i], matrix[i + 1] = matrix[i + 1], matrix[i]
                swapped = True
    return matrix

def sortMatrixButtonHandler(e):
    try:
        column = columnToSort.get()
        matrix = textMatrix.get(1.0, END)
        ansMatrix = []
        rows = matrix.split('\n')
        for i in range(len(rows)):
            ansMatrix.append([])
            for item in rows[i].split(' '):
                if (not(item == '')):
                    ansMatrix[i].append(int(item))
        window(True)
    except:
        messagebox.showerror("Ошибка", "Неверно введены данные")


root = Tk()
root.geometry('450x400')

Label(root, text="Введите матрицу \n (строки раделять с помощью Enter, солбцы с помощью пробела):", height=3).pack()
textMatrix = Text(width = 40, height=10)
textMatrix.pack()

Label(root, text="Введите номер столбца \n (счет начинается с 1)", height=3).pack()
columnToSort = Entry(width = 5)
columnToSort.pack()

sortMatrixButton = Button(root, text="Cортировать по возрастанию")
sortMatrixButton.bind('<Button-1>', sortMatrixButtonHandler)
sortMatrixButton.pack(pady=20)

def displayMatrix(matrix, parentFrame):
    for row in matrix:
        rowFrame = Frame(parentFrame)
        rowFrame.pack()
        for item in row:
            Label(rowFrame, text=item, width=6, height=3).pack(side=LEFT, anchor=W)

root.mainloop()
