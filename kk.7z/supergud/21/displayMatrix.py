from tkinter import *

matrix = [[1, 2, 3, 4, 5],
          [6, 3, 3, 4, 5],
          [1, 5, 3, 4, 5, 3, 54],
          [1, 4, 3, 4, 5],
          [1, 1, 3, 4, 5],]

def window(s):
    if (s):
        root2 = Tk()
        root2.geometry('450x400')

        centerFrame = Frame(root2).pack() #expand
        Label(centerFrame, text="Матрица:", height=3).pack()
        for row in matrix:
            rowFrame = Frame(parentFrame)
            rowFrame.pack()
            for item in row:
                Label(rowFrame, text=item, width=6, height=3).pack(side=LEFT, anchor=W)
        
        root2.mainloop()

window(False)
