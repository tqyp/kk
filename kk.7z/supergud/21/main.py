from tkinter import *
from random import randint
import os
 
def createMatrix(size):
    newMatrix = []
    for rowIndex in range(size):
        newMatrix.append([])
        for itemIndex in range(size):
            newMatrix[rowIndex].append(randint(0, 9)) 
    return newMatrix

def displayMatrix(matrix, parentFrame):
    if (len(parentFrame.winfo_children()) > 0):
        for item in parentFrame.winfo_children():
            item.destroy()
    parentFrame.pack()
    for row in matrix:
            rowFrame = Frame(parentFrame)
            rowFrame.pack()
            for item in row:
                Label(rowFrame, text=item, width=6, height=3).pack(side=LEFT, anchor=W)

def newMatrixButtonHandler(e):
    displayMatrix(createMatrix(5), matrixFrame)

def openF(e):
    os.system('sortMatrix.py')

root = Tk()
root.geometry('600x400')

buttonFrame = Frame(root).pack(side=TOP, pady = 10)
btn = Button(buttonFrame, text="Ввести и отсортировать \n по возрастанию", width=20)
btn.bind('<Button-1>', openF)
btn.pack()
newMatrixButton = Button(buttonFrame, text="Новая Матрица", width=20)
newMatrixButton.bind('<Button-1>', newMatrixButtonHandler)
newMatrixButton.pack()

matrixFrame = Frame(root)

displayMatrix(createMatrix(5), matrixFrame)

 
root.mainloop()
