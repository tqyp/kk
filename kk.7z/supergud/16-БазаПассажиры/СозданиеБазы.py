from sqlite3 import connect

connection = connect('passengerRecord.db')
cursor = connection.cursor()
cursor.execute('''create table passengers(aviaCode int primary key, destCityCode int,
               flightNum int, flightDate date, family text, address text)''')
cursor.execute('''insert into passengers values(23, 134,
               233, "2021-11-12", "Козлов", "г.Троицк ул.Савельева 17")''')
connection.commit()
connection.close()
