from tkinter import *
from tkinter import filedialog as fd
from tkinter import messagebox as mb
 
 
def insert_text():
       
    file_name = fd.askopenfilename()
    f = open(file_name)
    s = f.read()
    len(s)
    text.insert(1.0, s)
    f.close()
def insert_text1():
    file_name1 = fd.askopenfilename()
    f1 = open(file_name1)
    s1 = f1.read()
    len(s1)
    text1.insert(1.0, s1)
    f1.close()


def check():
       mb.showerror(
            "", 
            "неверно")
    
 


 
root = Tk()
root.geometry('650x500')
text = Text(width=30, height=25)
text.place(x=1, y =1)
text1 = Text(width=30, height=25)
text1.place(x=400, y =1)
b1 = Button(text="Открыть", command=insert_text)
b1.place(x=10, y= 410)
b2 = Button(text="Открыть", command=insert_text1)
b2.place(x=590, y= 410)
b2 = Button(text="Сравнить", command=check)
b2.place(x=300, y=300)

  
root.mainloop()
