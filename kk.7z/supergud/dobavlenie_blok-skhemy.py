from PIL import Image, ImageTk

def schema(): #для блок схемы
    window_schema = Toplevel(mainmenu)
    window_schema.geometry("660x600")
    window_schema.title('Блок схема')
    window_schema.resizable(False, False)
    canvas = Canvas(window_schema, width = 500, height = 600)
    canvas.pack()
    img = ImageTk.PhotoImage(Image.open("schema.png").resize((520, 450), Image.ANTIALIAS))
    canvas.create_image(10, 10, anchor = NW, image = img)
  
    button_close = Button(window_schema, text = 'Выход', font = 'courier 22', width = 10)
    button_close.place(x = 250, y = 500)
    button_close.bind('<Button-1>', lambda ok: window_schema.destroy())
    window_schema.mainloop()
