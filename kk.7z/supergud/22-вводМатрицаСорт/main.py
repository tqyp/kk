#!Разработать две программы. Первая принимает от пользователя квадратную матрицу, сортирует по убыванию заданную строку и выводит на 
#экран. Вторая программа запускает первую в качестве вновь созданного процесса.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label, Text
from tkinter import messagebox as mb

def rsort(a): # быстрая сортировка
    if a == []:
        return a
    l = [i for i in a if i > a[0]]
    m = [i for i in a if i == a[0]]
    r = [i for i in a if i < a[0]]
    return rsort(l) + m + rsort(r)

def matrix():
    text = tx1.get(1.0, 'end')
    try: # проверка введенной матрицы на соответствие
        length = len(text[:text.index('\n')].split(' '))# определение длины и ширины
        lines = text.replace('\n', ' ')[:-1]# сбор чисел в один список
        matrix = list(map(int, lines.split(' ')))# разбиение введенной матрицы на список чисел
        if len(matrix) / length != length:# проверка на квадратность
            mb.showerror('Ошибка!', 'Не является квадратной матрицей!')
            return
    except:
        mb.showerror('Ошибка!', 'Некорректный ввод матрицы!')
        return
    try:
        tx1.delete(1.0, 'end')
        inp = int(ent.get())-1
        cursor = 0
        column = []
        for i in range(0, len(matrix), length): # цикл по строкам списка
            row = list(map(str,matrix[i:i+length])) # определение строки
            tx1.insert('end', ' '.join(row)+'\n')
            column += [matrix[i+inp]] # запись элементов
            if cursor == inp: # определение строки для сортировки
                colsorted = ' '.join(list(map(str,rsort(matrix[i:i+length]))))
            cursor += 1
        tx1.insert('end', '\nОтсортированная строка: '+colsorted)
    except:
        mb.showerror('Ошибка!', 'Некорректный ввод номера строки!')
    

r = Tk()
r.title('Билет 22')
r.geometry('330x395')
r.resizable(0, 0)
lb1 = Label(r, text = 'Номер сортируемой строки:', font = 'Consolas 12')
lb1.place(x = 10, y = 10)
ent = Entry(r, font = 'Consolas 12', width = 5)
ent.place(x = 265, y = 10)
lb2 = Label(r, text = 'Введите матрицу:', font = 'Consolas 12')
lb2.place(x = 10, y = 45)
tx1 = Text(r, width = 37, height = 16)
tx1.place(x = 15, y = 80)
btn = Button(r, text = 'Сортировать', font = 'Consolas 12')
btn.bind('<Button-1>', lambda x: matrix())
btn.place(x = 15, y = 350)
r.mainloop()
