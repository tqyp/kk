#!Даны текстовый файл и слово. Перенесите в новый файл все строки, содержащие заданное слово. Предусмотрите промотр обоих файлов.
from tkinter.filedialog import askopenfilename as ask
from tkinter import Tk, Button, Entry, Label, Text
from tkinter import messagebox as mb

def save():
    try: # проверка формата и содержимого файла
        file = open(ent.get(), 'r', encoding = 'utf-8')
        text = file.read().split('\n')
    except:
        mb.showerror('Ошибка!', 'Неверный формат файла!')
        return
    newtext = [] # переменная для результата
    word = ent2.get()
    for line in text: # цикл поиска слова в строке
        if word in line:
            newtext += [line]         
    if ent3.get() == '': # проверка имени файла для сохранения
        name = 'result'
    else:
        name = ent3.get()
    file = open(name + '.txt', 'w', encoding = 'utf-8') # сохранение в файл
    file.write('\n'.join(newtext))
    file.close()
    mb.showinfo('Успешно!','Файл с результатом создан!')

def chfile(): # открытие через askopenfilename
    ent.delete(0, 'end')
    ent.insert('end', ask())
    ent.xview_moveto(1)

r = Tk()
r.title('Билет 5')
r.geometry('490x135')
r.resizable(0, 0)
lbl = Label(text = 'Выберите файл:', font = 'Consolas 12')
lbl.place(x = 10, y = 10)
ent = Entry(font = 'Consolas 14', width = 20)
ent.place(x = 150, y = 10)
lbl = Label(text = 'Введите слово:', font = 'Consolas 12')
lbl.place(x = 10, y = 50)
ent2 = Entry(font = 'Consolas 14', width = 20)
ent2.place(x = 150, y = 50)
btn = Button(text = '...', font = 'Consolas 10')
btn.bind('<Button-1>', lambda x: chfile())
btn.place(x = 365, y = 10)
lb2 = Label(text = 'Имя сохраняемого файла:', font = 'Consolas 12')
lb2.place(x = 10, y = 90)
ent3 = Entry(font = 'Consolas 14', width = 15)
ent3.place(x = 230, y = 90)
btn2 = Button(text = 'Сохранить', font = 'Consolas 10')
btn2.bind('<Button-1>', lambda x: save())
btn2.place(x = 395, y = 90)
r.mainloop()
