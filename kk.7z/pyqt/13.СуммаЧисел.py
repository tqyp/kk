from PyQt5.QtWidgets import * # Импорт модулей
import sys
from random import randint as ra

class Example(QWidget): # Создание окна программы
    def __init__(self):
        super().__init__()
        self.setGeometry(0,0,300,100)
        self.msg = QLabel(self)
        self.sp=[ra(-50,50) for i in range(10)] # Создание списка
        self.msg.setText("Список: "+str(self.sp))
        self.msg.move(10, 10)
        self.btn = QPushButton('Рассчитать', self) # Создание кнопки
        self.btn.clicked.connect(self.counter)
        self.btn.move(10, 40)
        self.msg2 = QLabel(self) # Лейбл для записи результата
        self.msg2.setText("Сумма пол. элементов:                ")
        self.msg2.move(10, 70)
    def counter(self): # Рассчет
        self.msg2.setText("Сумма пол. элементов: "+str(sum([i for i in self.sp if i>0])))
if __name__ == '__main__': # Запуск окна
    app = QApplication(sys.argv)
    w = Example()
    w.show()
    app.exec_()
