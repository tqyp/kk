from PyQt5.QtWidgets import * # Импорт модулей
from PyQt5.QtCore import *
import sqlite3,sys

conn = sqlite3.connect("sotrud.db") # Чтение из базы
cursor = conn.cursor()
data=cursor.execute("select * from sotruds").fetchall()
class Example(QMainWindow): # Создание окна
    def __init__(self):
        super().__init__()
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        grid_layout = QGridLayout()
        central_widget.setLayout(grid_layout)
        self.table = QTableWidget(self) # Создание таблицы
        self.table.setColumnCount(11)
        self.table.setRowCount(len(data))
        self.table.setHorizontalHeaderLabels(["Таб.номер", "Фамилия", "Дата рожд.","Профессия","Подр.","Дата приема","Дата нач.тр.д.","Оклад","Образ.","Спец.","Должность"])
        for i in range(len(data)): # Заполнение таблицы
            for j in range(11): self.table.setItem(i, j, QTableWidgetItem(str(data[i][j])))
        self.table.resizeColumnsToContents()
        grid_layout.addWidget(self.table, 0, 0)
        self.qle = QLineEdit(self) # Создание поля ввода
        grid_layout.addWidget(self.qle, 1, 0)
        self.btn = QPushButton('Найти фамилию', self) # Создание кнопки
        grid_layout.addWidget(self.btn, 2, 0)
        self.btn.clicked.connect(self.search)
    def search(self,ii=0):
        self.table.setRowCount(0) # Очистка таблицы
        self.table.setRowCount(len(data))
        for i in range(len(data)): # Заполнение таблицы
            if data[i][1]==self.qle.text() or self.qle.text()=='':
                for j in range(11): self.table.setItem(ii, j, QTableWidgetItem(str(data[i][j])))
                ii+=1
if __name__ == "__main__": # Создание окна
    app = QApplication(sys.argv)
    w = Example()
    w.show()
    app.exec_()
