import pygame # импорт модулей
import math
from random import randint as ra

wx = 800 # ширина окна
wy = 600 # высота окна
acc=1 # Точность
kl=10 # Размер одной единицы в пикселях
grap=['-3/x','-3/x+1'] # графики

pygame.init() # создание окна
screen = pygame.display.set_mode([wx,wy],pygame.FULLSCREEN)
mx,my=wx//2,wy//2, # определение середины окна
pygame.draw.line(screen,[255,255,255],[0,my],[wx,my])
pygame.draw.line(screen,[255,255,255],[mx,0],[mx,wy])
for i in range(len(grap)): # создание графиков
    spt=[] # точки
    col=[ra(50,255),ra(50,255),ra(50,255)] # цвет
    for x in range(-mx,mx,acc):
        try: y=eval(grap[i].replace('x',str(x/kl)))*kl # взятие графика из списка и замена "х" на значение
        except: continue
        spt+=[[x+mx,y+my]]
        if len(spt)>2: # прорисовка графика
            pygame.draw.lines(screen,col,0,spt)
            pygame.time.delay(5)
            pygame.display.flip()
pygame.time.delay(2000)
pygame.quit()
