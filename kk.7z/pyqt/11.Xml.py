from PyQt5.QtWidgets import * # Импорт модулей
from PyQt5.QtCore import *
from PyQt5.Qt import *
from xml.dom import minidom
import sys

class Example(QMainWindow): # Создание окна программы
    def __init__(self):
        super().__init__()
        self.setGeometry(0,0,280,300)
        self.qle = QPlainTextEdit(self) # Создание поля ввода
        self.qle.setGeometry(QRect(10, 50, 260, 220))
        self.btn = QPushButton('Выберите xml', self) # Создание кнопки
        self.btn.clicked.connect(self.showDialog)
        self.btn.move(10, 10)
    def showDialog(self): # Диалог файлов
        fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
        self.qle.clear()
        
        self.dom = minidom.parse(fname)
        self.collection = self.dom.documentElement
        self.linesArr = self.collection.getElementsByTagName('text')
        for line in self.linesArr: # Вывод текста из тега и текста между <text></text>
            self.qle.appendPlainText(line.getAttribute('what'))
            self.qle.appendPlainText(line.childNodes[0].data)
if __name__ == '__main__': # Запуск окна
    app = QApplication(sys.argv)
    w = Example()
    w.show()
    app.exec_()

