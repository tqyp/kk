import pygame # импорт модуля
class Obj(pygame.sprite.Sprite): # класс спрайтов
    def __init__(self,typ,x,y,pic):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(pic) # загрузка изображений
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.nap,self.typ=5,typ # переменные типа спрайта и направления
    def update(self): # обновление мячика
        if self.typ==0: return
        self.rect.x += self.nap
        if self.rect.left > 750: self.nap=-5 # изменение направления
        elif self.rect.right < 50: self.nap=5
pygame.init() # создание окна
screen = pygame.display.set_mode((800, 600))
clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group() # создание объектов в окне
player = Obj(0,50,300,'k.png')
player2 = Obj(0,750,300,'k2.png')
ball = Obj(1,100,300,'b.png')
all_sprites.add(player,player2,ball)
while True: # запуск анимации
    clock.tick(60)
    all_sprites.update()
    screen.fill((255,255,255))
    all_sprites.draw(screen) # отрисовка
    pygame.display.flip()
