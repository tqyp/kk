from PyQt5.QtWidgets import * # Импорт модулей
import sys

class Example(QWidget): # Создание окна
    def __init__(self):
        super().__init__()
        layout = QGridLayout() # Создание сетки для расположения виджетов 
        self.setLayout(layout)
        ls=[['Как относишься к PyQt?','плохо','нейтрально','отлично','#12 из 10'],
            ['PyQt - лучшее изобретение человечества?','да','нет','#разве есть сомнения?','возможно'],
            ['Есть что-либо лучше PyQt?','да','да','#нет','да']]
        self.rezs=[0,0,0] # для хранения ответов на вопросы
        for j in range(3): # Создание циклом лейблов и радиокнопок
            l1 = QLabel(ls[j][0])
            layout.addWidget(l1, j*5, 0)
            group=QButtonGroup(self) # Сбор кнопок одного вопроса в группу
            for i in range(4): # Создание радиокнопок 
                rbs = QRadioButton(ls[j][i+1].replace('#',''))
                rbs.count = [ls[j][i+1][0],j] # count(можно любое имя) - привязанная к кнопке переменная для хранения любой инфы   
                rbs.toggled.connect(self.onClicked)
                group.addButton(rbs)
                layout.addWidget(rbs, j*5+i+1, 0)
        button = QPushButton("Завершить")
        button.clicked.connect(self.rez)
        layout.addWidget(button, j*5+i+2, 0)
    def onClicked(self): # при клике по радиокнопке с помощью self.sender() обращаемся к переменной count и изменяем результаты теста
        if self.sender().count[0]=='#': self.rezs[self.sender().count[1]]=1
        else: self.rezs[self.sender().count[1]]=0
    def rez(self): # Считываем результаты и блокируем тест
        self.setEnabled(False) 
        dlg = QDialog(self)
        dlg.layout = QVBoxLayout()
        message = QLabel("Тест завершен!\nРезультат: "+str(self.rezs.count(1)+2))
        dlg.layout.addWidget(message)
        dlg.setLayout(dlg.layout)
        dlg.exec()
if __name__ == "__main__": # Запуск окна
    app = QApplication(sys.argv)
    w=Example()
    w.show()
    app.exec_()
