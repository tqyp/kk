from PyQt5.QtWidgets import * # Импорт модулей
from PyQt5.QtGui import *
import sys

class Example(QWidget): # Создание окна программы
    def __init__(self):
        super().__init__()
        self.setGeometry(0,0,170,200)
        self.msg = QLabel(self)
        self.msg.setText("Введите кол-во букв в слове:")
        self.msg.move(10, 10)
        self.qle = QLineEdit(self) # Создание поля ввода
        self.qle.move(10, 40)
        self.btn = QPushButton('Выберите файл', self) # Создание кнопки
        self.btn.clicked.connect(self.showDialog)
        self.btn.move(10, 70)
        self.msg2 = QLabel(self) # Лейбл для записи результата
        self.msg2.setText("Искомое слово:                                ")
        self.msg2.move(10, 100)
    def showDialog(self): # Диалог файлов
        try:
            int(self.qle.text()) # проверка ввода и открытие файла
            fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
            f = open(fname, 'r')
        except: return
        tx=f.read().replace('\n',' ').split(' ') # перевод текста в список слов
        for i in range(len(tx)): # Проход по списку и поиск совпадений
            if len(tx[i])==int(self.qle.text()):
                self.msg2.setText("Искомое слово: "+tx[i])
                break
if __name__ == '__main__': # Запуск окна
    app = QApplication(sys.argv)
    w = Example()
    w.show()
    app.exec_()
