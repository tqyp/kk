from PyQt5.QtWidgets import * # Импорт модулей
from PyQt5.QtCore import *
from PyQt5.Qt import *
from datetime import datetime
import sys

class Example(QMainWindow): # Создание окна программы
    def __init__(self):
        super().__init__()
        self.setGeometry(0,0,280,300)
        self.qle = QPlainTextEdit(self) # Создание поля ввода
        self.qle.setGeometry(QRect(10, 50, 260, 220))
        self.btn = QPushButton('Выберите файл', self) # Создание кнопки
        self.btn.clicked.connect(self.showDialog)
        self.btn.move(10, 10)
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.chstbar)
        self.timer.start()
    def showDialog(self): # Диалог файлов
        fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
        f = open(fname, 'r')
        self.qle.clear()
        self.qle.setPlainText(f.read())
    def chstbar(self):
        self.statusBar().showMessage(datetime.today().strftime("%m.%d.%Y %H:%M:%S"))
if __name__ == '__main__': # Запуск окна
    app = QApplication(sys.argv)
    w = Example()
    w.show()
    sys.exit(app.exec_())

