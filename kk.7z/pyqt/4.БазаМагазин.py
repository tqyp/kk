from PyQt5.QtWidgets import * # Импорт модулей
from PyQt5.QtGui import *
from PyQt5.QtCore import *
import sqlite3,sys

conn = sqlite3.connect("shop.db") # Чтение из базы
cursor = conn.cursor()
data=cursor.execute("select * from things").fetchall()
class Example(QMainWindow): # Создание окна
    def __init__(self):
        super().__init__()
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)
        grid_layout = QGridLayout()
        central_widget.setLayout(grid_layout)
        self.table = QTableWidget(self) # Создание таблицы
        self.table.setColumnCount(3)
        self.table.setRowCount(len(data))
        self.table.setHorizontalHeaderLabels(["Товар", "Цена", "Кол-во"])
        for i in range(len(data)): # Заполнение таблицы
            for j in range(3): self.table.setItem(i, j, QTableWidgetItem(str(data[i][j])))
        self.table.resizeColumnsToContents()
        self.table.cellChanged.connect(lambda x: self.chdata()) # Изменение итога при изменении ячейки
        grid_layout.addWidget(self.table, 0, 0)
        self.la = QLabel() # Создание лейбла
        self.la.setText("Общая сумма: 0")
        self.la.setAlignment(Qt.AlignCenter)
        grid_layout.addWidget(self.la, 1, 0)
    def chdata(self,itog=0): # Функция записи итога в лейбл
        for i in range(len(data)): itog+=int(self.table.item(i,1).text())*int(self.table.item(i,2).text())
        self.la.setText("Общая сумма: "+str(itog))
if __name__ == '__main__': # запуск приложения
    app = QApplication(sys.argv)
    w=Example()
    w.show()
    app.exec_()
