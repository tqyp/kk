from PyQt5.QtWidgets import * # Импорт модулей
import sys

def bank(x,y): # Функция рассчета итоговой суммы
    for i in range(y): x=x*1.1
    return round(x,5)
class Example(QWidget): # Создание окна программы
    def __init__(self):
        super().__init__()
        self.setGeometry(0,0,220,200)
        self.msg = QLabel(self)
        self.msg.setText("Введите размер вклада и кол-во лет:")
        self.msg.move(10, 10)
        self.qle = QLineEdit(self) # Создание поля ввода
        self.qle.move(10, 40)
        self.qle2 = QLineEdit(self)
        self.qle2.move(10, 70)
        self.btn = QPushButton('Рассчитать', self) # Создание кнопки
        self.btn.clicked.connect(self.banker)
        self.btn.move(10, 100)
        self.msg2 = QLabel(self) # Лейбл для записи результата
        self.msg2.setText("Итоговая сумма:                                ")
        self.msg2.move(10, 130)
    def banker(self): # Cбор и вывод информации
        try: x,y=int(self.qle.text()),int(self.qle2.text())
        except: return
        self.msg2.setText("Итоговая сумма: "+str(bank(x,y)))
if __name__ == '__main__': # Запуск окна
    app = QApplication(sys.argv)
    w = Example()
    w.show()
    app.exec_()
