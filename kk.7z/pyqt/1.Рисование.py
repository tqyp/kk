import sys #импорт модулей
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

class Example(QWidget): # создание окна
    def __init__(self): super().__init__()
    def paintEvent(self, e): # запуск события рисования
        qp = QPainter()
        qp.begin(self)
        pen = QPen()
        qp.setPen(pen)
        brush = QBrush(Qt.BDiagPattern) # настройка заливки
        brush.setColor(QColor(255, 255, 0))
        qp.setBrush(brush)
        qp.drawRoundedRect(20, 20 ,150, 100, 15, 15) # рисование прямоугольника
        qp.end()
if __name__ == '__main__': # запуск приложения
    app = QApplication(sys.argv)
    w=Example()
    w.show()
    app.exec_()
