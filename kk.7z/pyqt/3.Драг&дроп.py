import sys # Импорт модулей
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtCore import *

class Button(QPushButton): # класс кнопки
    def __init__(self, title, parent): super().__init__(title, parent)
    def mouseMoveEvent(self, e): #
        mimeData = QMimeData()
        drag = QDrag(self)
        drag.setMimeData(mimeData)
        drag.setHotSpot(e.pos()-self.rect().topLeft())
        dropAction = drag.exec_(Qt.MoveAction)
class Example(QWidget): # создание окна
    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.btns=[0,0,0,0,0,0] # создание кнопок
        for i in range(6):
            self.btns[i] = Button('Button'+str(i), self)
            self.btns[i].enterEvent = lambda x,i=i: self.gett(i)
            self.btns[i].move(10+i*90, 10)
    def dragEnterEvent(self, e):e.accept() # начало перемещения
    def gett(self,i): self.j=i # запоминание перемещаемой кнопки
    def dropEvent(self, e): # изменение координат кнопки при отпускании
        self.btns[self.j].move(e.pos())
        e.setDropAction(Qt.MoveAction)
        e.accept()
if __name__ == '__main__': # Запуск окна
    app=QApplication(sys.argv)
    w=Example()
    w.show()
    app.exec_()
