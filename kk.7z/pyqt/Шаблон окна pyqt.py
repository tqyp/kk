from PyQt5.QtWidgets import * # если не понятно что импортировать, лучше все 4
from PyQt5.QtCore import *
from PyQt5.QtGui import *
import sys

class Example(QWidget): # QWidget или QMainWindow, в зависимости от задания
    def __init__(self):
        super().__init__()
        # тут все элементы
    # тут все функции

if __name__ == '__main__':
    app = QApplication(sys.argv)
    w = Example()
    w.show()
    app.exec_()
