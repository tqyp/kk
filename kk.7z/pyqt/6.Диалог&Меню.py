from PyQt5.QtWidgets import * # Импорт модулей
from PyQt5.QtGui import *
import sys

class Example(QMainWindow): # Создание окна программы
    def __init__(self):
        super().__init__()
        menuBar = self.menuBar()
        Men = QMenu("Dialogs", self)
        menuBar.addMenu(Men)
        bnames=['Input Dialog','Color Dialog','Font Dialog','File Dialog','Custom Dialog']
        for i in range(5): # Создание пунктов меню циклом, чтоб короче было
            act = QAction(bnames[i], self)
            Men.addAction(act)
            act.triggered.connect(eval('self.showDialog'+str(i)))
    def showDialog0(self): # Диалог ввода
        text,ok = QInputDialog.getText(self, 'Input Dialog','Enter text:')
        if ok: print(str(text))
    def showDialog1(self): # Диалог цвета
        col = QColorDialog.getColor()
        print(col.name())
    def showDialog2(self): # Диалог шрифта
        font, ok = QFontDialog.getFont()
        if ok: print(font.family(),font.weight())
    def showDialog3(self): # Диалог файлов
        fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
        f = open(fname, 'r')
        print(f.read())
    def showDialog4(self): # Настраиваемый диалог (как обычное окно)
        dlg = QDialog(self)
        dlg.layout = QVBoxLayout()
        message = QLabel("Text\nVery some text")
        dlg.layout.addWidget(message)
        dlg.setLayout(dlg.layout)
        dlg.exec()
if __name__ == '__main__': # Запуск окна
    app = QApplication(sys.argv)
    w=Example()
    w.show()
    sys.exit(app.exec_())
